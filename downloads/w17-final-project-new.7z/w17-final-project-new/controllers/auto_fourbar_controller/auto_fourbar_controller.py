from controller import Robot, Emitter
import math
import time

TASK_POINTS = [
    (0.00, 0.00),
    (6.95, 6.05),
    (12.46, -0.25),
    (6.24, -6.41)
]

HOOP_POS = (6.23, -0.18, 0.742838)
BALL_Z = 0.38
G = 9.8
THROW_ANGLE_DEG = 50

robot = Robot()
timestep = int(robot.getBasicTimeStep())

# 初始化裝置
wheels = [robot.getDevice(f"wheel{i+1}") for i in range(4)]
for wheel in wheels:
    wheel.setPosition(float('inf'))
    wheel.setVelocity(0)
imu = robot.getDevice("imu")
imu.enable(timestep)
gps = robot.getDevice("gps")
gps.enable(timestep)
motor = robot.getDevice('motor1')
sensor = robot.getDevice('motor1_sensor')
sensor.enable(timestep)

# emitter 必須在 youbot 的 children 裡宣告
emitter = robot.getDevice('emitter')

def get_position():
    pos = gps.getValues()
    return (pos[0], pos[1])

def angle_diff(a, b):
    d = a - b
    while d > math.pi:
        d -= 2 * math.pi
    while d < -math.pi:
        d += 2 * math.pi
    return d

def angle_between_vectors(ax, ay, bx, by):
    norm_a = math.hypot(ax, ay)
    norm_b = math.hypot(bx, by)
    if norm_a == 0 or norm_b == 0:
        return 0
    ax, ay = ax / norm_a, ay / norm_a
    bx, by = bx / norm_b, by / norm_b
    dot = ax * bx + ay * by
    det = ax * by - ay * bx
    angle_rad = math.atan2(det, dot)
    return math.degrees(angle_rad)

def set_wheel_velocity(v1, v2, v3, v4):
    wheels[0].setVelocity(v1)
    wheels[1].setVelocity(v2)
    wheels[2].setVelocity(v3)
    wheels[3].setVelocity(v4)

def rotate_by_angle(target_angle_deg, fast_velocity=10.0, slow_velocity=1.0, tolerance_deg=1.0):
    start_yaw = imu.getRollPitchYaw()[2]
    target_rad = math.radians(target_angle_deg)
    slow_zone = math.radians(5)
    direction = -1 if target_angle_deg > 0 else 1

    while robot.step(timestep) != -1:
        now_yaw = imu.getRollPitchYaw()[2]
        turned = angle_diff(now_yaw, start_yaw)
        remain = abs(target_rad) - abs(turned)
        if remain < math.radians(tolerance_deg):
            break
        speed = slow_velocity if remain < slow_zone else fast_velocity
        set_wheel_velocity(-direction * speed, direction * speed,
                           -direction * speed, direction * speed)
    set_wheel_velocity(0, 0, 0, 0)
    for _ in range(5):
        robot.step(timestep)

def move_to_point_and_face_to(target_point, face_to_point, tolerance_pos=0.08):
    fast_velocity = 10.0
    slow_velocity = 1.0
    MAX_STEP = 1200
    # 1. 先轉向目標點
    now_pos = get_position()
    yaw = imu.getRollPitchYaw()[2]
    head_vec = (math.cos(yaw), math.sin(yaw))
    tar_vec = (target_point[0] - now_pos[0], target_point[1] - now_pos[1])
    angle1 = angle_between_vectors(head_vec[0], head_vec[1], tar_vec[0], tar_vec[1])
    print(f"[導航] 旋轉朝向目標點 {angle1:.2f}°")
    rotate_by_angle(angle1)
    # 2. 前進
    step = 0
    while step < MAX_STEP:
        robot.step(timestep)
        now_pos = get_position()
        dx = target_point[0] - now_pos[0]
        dy = target_point[1] - now_pos[1]
        dist = math.hypot(dx, dy)
        if dist < tolerance_pos:
            break
        v = fast_velocity if dist > 0.3 else slow_velocity
        set_wheel_velocity(v, v, v, v)
        step += 1
    set_wheel_velocity(0, 0, 0, 0)
    for _ in range(5):
        robot.step(timestep)
    print(f"[導航] 到達目標點 (距離: {dist:.3f})")
    # 3. 只最後一次轉向籃框
    now_pos = get_position()
    yaw = imu.getRollPitchYaw()[2]
    head_vec = (math.cos(yaw), math.sin(yaw))
    face_vec = (face_to_point[0] - now_pos[0], face_to_point[1] - now_pos[1])
    angle2 = angle_between_vectors(head_vec[0], head_vec[1], face_vec[0], face_vec[1])
    print(f"[導航] 朝向籃框旋轉 {angle2:.2f}°")
    rotate_by_angle(angle2)
    set_wheel_velocity(0, 0, 0, 0)
    for _ in range(5):
        robot.step(timestep)

def calc_throw_velocity(shooter_xy, hoop_xyz, z0=BALL_Z, angle_deg=THROW_ANGLE_DEG):
    x0, y0 = shooter_xy
    xh, yh, zh = hoop_xyz
    dx = xh - x0
    dy = yh - y0
    dz = zh - z0
    d = math.hypot(dx, dy)
    angle_rad = math.radians(angle_deg)
    numerator = G * d**2
    denominator = 2 * (d * math.tan(angle_rad) + z0 - zh) * (math.cos(angle_rad) ** 2)
    print(f"[DEBUG] d={d}, angle_rad={angle_rad}, numerator={numerator}, denominator={denominator}")
    if denominator <= 0 or math.isnan(denominator):
        print("[警告] denominator <= 0 或 NaN，調高仰角再試")
        raise Exception("仰角不合理，請調整")
    v = math.sqrt(numerator / denominator)
    print(f"[DEBUG] 計算出v={v}")
    return v, angle_deg

def create_ball():
    print("[機器人] 產生新球（發送r）")
    emitter.send("r".encode())
    t_end = time.time() + 0.3
    while time.time() < t_end:
        robot.step(timestep)

def trigger_throw(v, angle_deg):
    pos = 0.8 + (v - 5) * 0.02
    print(f"[機器人] trigger_throw: v={v}, angle={angle_deg}, pos={pos}")
    if math.isnan(pos):
        print("[錯誤] 計算出的 pos 是 NaN，將跳過 setPosition")
        return
    print("[機器人] 發送m（擊球）")
    emitter.send("m".encode())
    motor.setPosition(pos)
    t_end = time.time() + 0.4
    while time.time() < t_end:
        robot.step(timestep)
    print("[機器人] 回位（模擬自動按k）")
    motor.setPosition(0.0)
    t_end = time.time() + 0.4
    while time.time() < t_end:
        robot.step(timestep)

def wait_ball_result():
    time.sleep(1.2)
    return True

def auto_task():
    for idx, pt in enumerate(TASK_POINTS):
        print(f"\n==== 前往定點 {idx+1}: {pt} ====")
        move_to_point_and_face_to(pt, HOOP_POS[:2])
        print(f"[流程] 開始投球，需進5顆...")
        goal = 0
        while goal < 5:
            create_ball()  # 產生球
            now_xy = get_position()
            try:
                v, angle = calc_throw_velocity(now_xy, HOOP_POS)
            except Exception as e:
                print(f"[警告] 投球參數無效({e})，嘗試調整仰角")
                try:
                    v, angle = calc_throw_velocity(now_xy, HOOP_POS, angle_deg=55)
                except Exception as ee:
                    print(f"[錯誤] 仰角55仍無效({ee})，本球跳過")
                    continue
            trigger_throw(v, angle)  # 自動 m/k
            if wait_ball_result():
                goal += 1
                print(f"[命中] 目前累計：{goal}/5")
            else:
                print("[未命中] 重投！")
    print("全部定點投球任務完成！")

print("==== 自動百發百中定點投籃流程啟動 ====")
auto_task()