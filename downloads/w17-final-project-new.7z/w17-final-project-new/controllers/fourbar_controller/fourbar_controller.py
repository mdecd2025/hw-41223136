from controller import Robot, Keyboard, Receiver
import math

# ==== Constants ====
TIME_STEP = 32
MAX_VELOCITY = 20.0
ANGLE_STEP = 40 * math.pi / 180  # 40 deg in radians
POSITION_M = ANGLE_STEP
POSITION_K = 0.0

# 原地旋轉速度設定：每秒 1 度 = 0.01745 rad/s
DEG_PER_SEC = 10.0
OMEGA = DEG_PER_SEC * math.pi / 180.0  # 1deg/s in rad/s

# 麥克納姆參數
WHEEL_RADIUS = 0.1
BOT_L = 0.471
BOT_W = 0.376

robot = Robot()
timestep = int(robot.getBasicTimeStep())
keyboard = Keyboard()
keyboard.enable(timestep)

# Devices
try:
    motor = robot.getDevice('motor1')
    sensor = robot.getDevice('motor1_sensor')
    sensor.enable(timestep)
    mechanism_enabled = True
except Exception:
    mechanism_enabled = False

try:
    wheels = [robot.getDevice(f"wheel{i+1}") for i in range(4)]
    for wheel in wheels:
        wheel.setPosition(float('inf'))
        wheel.setVelocity(0)
    platform_enabled = True
except Exception:
    platform_enabled = False

try:
    receiver = robot.getDevice('rcv')
    receiver.enable(timestep)
    receiver_enabled = True
except Exception:
    receiver_enabled = False

# ==== 新增自動定點移動所需裝置 ====
try:
    imu = robot.getDevice("imu")
    imu.enable(timestep)
    gps = robot.getDevice("gps")
    gps.enable(timestep)
    auto_nav_enabled = True
except Exception:
    auto_nav_enabled = False

current_state = "allow_m"
key_pressed = {'k': False, 'm': False, 'r': False}

# === 自動導航輔助函數 ===
def get_yaw():
    return imu.getRollPitchYaw()[2]

def get_position():
    pos = gps.getValues()
    return (pos[0], pos[1])

def angle_diff(a, b):
    d = a - b
    while d > math.pi:
        d -= 2 * math.pi
    while d < -math.pi:
        d += 2 * math.pi
    return d

def angle_between_vectors(ax, ay, bx, by):
    norm_a = math.hypot(ax, ay)
    norm_b = math.hypot(bx, by)
    if norm_a == 0 or norm_b == 0:
        return 0
    ax, ay = ax / norm_a, ay / norm_a
    bx, by = bx / norm_b, by / norm_b
    dot = ax * bx + ay * by
    det = ax * by - ay * bx
    angle_rad = math.atan2(det, dot)
    return math.degrees(angle_rad)

def set_wheel_velocity(v1, v2, v3, v4):
    wheels[0].setVelocity(v1)
    wheels[1].setVelocity(v2)
    wheels[2].setVelocity(v3)
    wheels[3].setVelocity(v4)

def rotate_by_angle(target_angle_deg, fast_velocity=MAX_VELOCITY, slow_velocity=1.0, tolerance_deg=1.0):
    start_yaw = get_yaw()
    target_rad = math.radians(target_angle_deg)
    slow_zone = math.radians(5)
    direction = -1 if target_angle_deg > 0 else 1

    while True:
        robot.step(timestep)
        now_yaw = get_yaw()
        turned = angle_diff(now_yaw, start_yaw)
        remain = abs(target_rad) - abs(turned)

        if remain < math.radians(tolerance_deg):
            break

        if remain < slow_zone:
            speed = slow_velocity
        else:
            speed = fast_velocity

        set_wheel_velocity(-direction * speed, direction * speed,
                           -direction * speed, direction * speed)

    set_wheel_velocity(0, 0, 0, 0)
    print(f"[完成] 旋轉角度：{math.degrees(turned):.2f}°")

def move_to_point_and_face_to(target_point, face_to_point, tolerance_pos=0.05):
    fast_velocity = 10.0
    slow_velocity = 1.0
    MAX_STEP = 1200

    # === 第一階段：轉向目標點 ===
    now_pos = get_position()
    yaw = get_yaw()
    head_vec = (math.cos(yaw), math.sin(yaw))
    tar_vec = (target_point[0] - now_pos[0], target_point[1] - now_pos[1])
    angle1 = angle_between_vectors(head_vec[0], head_vec[1], tar_vec[0], tar_vec[1])
    print(f"[階段1] 旋轉朝向目標點 {angle1:.2f}°")
    rotate_by_angle(angle1)

    # === 第二階段：前進 ===
    step = 0
    while step < MAX_STEP:
        robot.step(timestep)
        now_pos = get_position()
        dx = target_point[0] - now_pos[0]
        dy = target_point[1] - now_pos[1]
        dist = math.hypot(dx, dy)
        if dist < tolerance_pos:
            break

        v = fast_velocity if dist > 0.3 else slow_velocity
        set_wheel_velocity(v, v, v, v)
        step += 1
    set_wheel_velocity(0, 0, 0, 0)
    for _ in range(8):
        robot.step(timestep)
    print(f"[階段2] 到達目標點 (距離: {dist:.3f})")

    # === 第三階段：轉向 face_to_point ===
    now_pos = get_position()
    yaw = get_yaw()
    head_vec = (math.cos(yaw), math.sin(yaw))
    face_vec = (face_to_point[0] - now_pos[0], face_to_point[1] - now_pos[1])
    angle2 = angle_between_vectors(head_vec[0], head_vec[1], face_vec[0], face_vec[1])
    print(f"[階段3] 最終朝向 (0,0) 旋轉 {angle2:.2f}°")
    rotate_by_angle(angle2)
    set_wheel_velocity(0, 0, 0, 0)
    for _ in range(8):
        robot.step(timestep)

print("平台操作：")
print("  方向鍵：移動/旋轉")
print("  V鍵：原地逆時針旋轉，B鍵：原地順時針旋轉（每秒 1 度）")
print("  U/I/O/P：自動定點導航")
print("  (r/m/k 動作自動由 supervisor 指令發送) Q鍵：離開")

while robot.step(timestep) != -1:
    # 1. 處理自動訊息 (來自 Supervisor)
    if receiver_enabled:
        while receiver.getQueueLength() > 0:
            msg = receiver.getString()
            if mechanism_enabled:
                if msg == 'a':
                    current_state = "allow_m"
                elif msg == 'm' and current_state == "allow_m":
                    motor.setPosition(POSITION_M)
                    current_state = "allow_k"
                elif msg == 'k' and current_state == "allow_k":
                    motor.setPosition(POSITION_K)
                    current_state = "allow_m"
            receiver.nextPacket()

    # 2. 處理手動鍵盤（保留 m/k/r 手動模式，或僅限自動）
    key = keyboard.getKey()

    # Platform manual control
    if platform_enabled:
        if key == Keyboard.UP:
            for wheel in wheels:
                wheel.setVelocity(MAX_VELOCITY)
        elif key == Keyboard.DOWN:
            for wheel in wheels:
                wheel.setVelocity(-MAX_VELOCITY)
        elif key == Keyboard.LEFT:
            wheels[0].setVelocity(MAX_VELOCITY)
            wheels[1].setVelocity(-MAX_VELOCITY)
            wheels[2].setVelocity(MAX_VELOCITY)
            wheels[3].setVelocity(-MAX_VELOCITY)
        elif key == Keyboard.RIGHT:
            wheels[0].setVelocity(-MAX_VELOCITY)
            wheels[1].setVelocity(MAX_VELOCITY)
            wheels[2].setVelocity(-MAX_VELOCITY)
            wheels[3].setVelocity(MAX_VELOCITY)
        elif key == ord('V') or key == ord('v'):
            print("V pressed")
            omega = OMEGA
            r, L, W = WHEEL_RADIUS, BOT_L, BOT_W
            v_x = v_y = 0
            w1 = (1/r) * (v_x - v_y - (L+W)*omega)
            w2 = (1/r) * (v_x + v_y + (L+W)*omega)
            w3 = (1/r) * (v_x + v_y - (L+W)*omega)
            w4 = (1/r) * (v_x - v_y + (L+W)*omega)
            wheels[0].setVelocity(w1)
            wheels[1].setVelocity(w2)
            wheels[2].setVelocity(w3)
            wheels[3].setVelocity(w4)
        elif key == ord('B') or key == ord('b'):
            print("B pressed")
            omega = -OMEGA
            r, L, W = WHEEL_RADIUS, BOT_L, BOT_W
            v_x = v_y = 0
            w1 = (1/r) * (v_x - v_y - (L+W)*omega)
            w2 = (1/r) * (v_x + v_y + (L+W)*omega)
            w3 = (1/r) * (v_x + v_y - (L+W)*omega)
            w4 = (1/r) * (v_x - v_y + (L+W)*omega)
            wheels[0].setVelocity(w1)
            wheels[1].setVelocity(w2)
            wheels[2].setVelocity(w3)
            wheels[3].setVelocity(w4)
        # ==== UIOP 自動定點導航 ====
        elif (key == ord('U') or key == ord('u')) and auto_nav_enabled:
            print("執行 U：前往 (6.23, 6.05)，朝向籃框")
            move_to_point_and_face_to((6.57369, 6.23308), (6.23, -0.18))
        elif (key == ord('I') or key == ord('i')) and auto_nav_enabled:
            print("執行 I：前往 (12.46, -0.25)，朝向籃框")
            move_to_point_and_face_to((12.70853, -0.22909), (6.23, -0.18))
        elif (key == ord('O') or key == ord('o')) and auto_nav_enabled:
            print("執行 O：前往 (6.23, -6.41)，朝向籃框")
            move_to_point_and_face_to((6.5669, -6.60899), (6.23, -0.18))
        elif (key == ord('P') or key == ord('p')) and auto_nav_enabled:
            print("執行 P：前往 (0, 0)，朝向籃框")
            move_to_point_and_face_to((-0.006, 0.003), (6.23, -0.18))
        elif key == ord('Q') or key == ord('q'):
            print("Exiting...")
            break
        else:
            for wheel in wheels:
                wheel.setVelocity(0)

    # (可選) 若還允許平台手動 m/k/r 控制，可保留下方
    if mechanism_enabled:
        _current_motor_position = sensor.getValue()
        # M key: only take action if allowed and not held
        if key == ord('M') or key == ord('m'):
            if not key_pressed['m'] and current_state == "allow_m":
                motor.setPosition(POSITION_M)
                current_state = "allow_k"
            key_pressed['m'] = True
        else:
            key_pressed['m'] = False

        # K key: only take action if allowed and not held
        if key == ord('K') or key == ord('k'):
            if not key_pressed['k'] and current_state == "allow_k":
                motor.setPosition(POSITION_K)
                current_state = "allow_m"
            key_pressed['k'] = True
        else:
            key_pressed['k'] = False

        # R key: 進入 allow_m 狀態
        if key == ord('R') or key == ord('r'):
            if not key_pressed['r']:
                current_state = "allow_m"
            key_pressed['r'] = True
        else:
            key_pressed['r'] = False